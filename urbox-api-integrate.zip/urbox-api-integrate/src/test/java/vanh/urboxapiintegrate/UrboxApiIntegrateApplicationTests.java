package vanh.urboxapiintegrate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrboxApiIntegrateApplicationTests {

    @Test
    void contextLoads() {
    }

}
