package com.oauthdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OAuthDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
