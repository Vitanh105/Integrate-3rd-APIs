package com.vanh.urboxapiintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrboxApiIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(UrboxApiIntegrationApplication.class, args);
    }

}
