package com.vanh.urboxapiintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrboxApiIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
